# Kalite Yönetim Sistemi (Quality Management System)

CodeIgniter 3.x framework'ü kullanılarak geliştirilmiş kapsamlı bir kalite yönetim ve üretim kontrol sistemi.

kullanıcı bilgileri
kullanıcı adı : admin
şifre : 123456



## 🚀 Özellikler

### Kalite Kontrol Modülleri
- **Girdi Kontrolü** - Gelen malzemelerin kalite kontrolü
- **Proses Kontrolü** - Üretim sürecindeki kalite kontrolleri
- **Final Kontrolü** - Son ürün kalite kontrolü
- **Ölçüm Kontrolü** - Ölçüm sonuçlarının takibi

### Yönetim Modülleri
- **Malzeme Yönetimi** - Hammadde ve malzeme takibi
- **Tedarikçi Yönetimi** - Tedarikçi bilgileri ve değerlendirmesi
- **Ürün Yönetimi** - Ürün kataloğu ve spesifikasyonları
- **Müşteri Yönetimi** - Müşteri bilgileri ve takibi

### Planlama ve Organizasyon
- **Planlama Modülü** - Üretim ve kalite planlaması
- **İş Emri Yönetimi** - İş emirlerinin takibi
- **Kontrol No Sistemi** - Benzersiz kontrol numarası oluşturma

### Teknik Özellikler
- **QR Kod Üretimi** - Ürün ve süreç takibi için QR kod desteği
- **Excel Export/Import** - Veri alışverişi için Excel desteği
- **Görsel Yönetimi** - Resim galerisi ve görsel dokümantasyon
- **Kullanıcı Rolleri** - Detaylı yetki ve rol yönetimi
- **Çok Dilli Destek** - Türkçe ve İngilizce dil desteği

## 📋 Sistem Gereksinimleri

- **PHP**: 7.0 veya üzeri
- **MySQL**: 5.6 veya üzeri
- **Apache/Nginx**: Web sunucusu
- **Composer**: Paket yöneticisi

## 🛠️ Kurulum

### 1. Proje Dosyalarını İndirin
```bash
git clone [repository-url]
cd cms/panel
```

### 2. Composer Bağımlılıklarını Yükleyin
```bash
composer install
```

### 3. Veritabanı Konfigürasyonu
`application/config/database.php` dosyasını düzenleyin:
```php
$db['default'] = array(
    'hostname' => 'localhost',
    'username' => 'your_username',
    'password' => 'your_password',
    'database' => 'your_database_name',
    'dbdriver' => 'mysqli',
);
```

### 4. Base URL'yi Ayarlayın
`application/config/config.php` dosyasında:
```php
$config['base_url'] = 'http://your-domain.com/';
```

### 5. Veritabanını İçe Aktarın
```bash
mysql -u username -p database_name < djgekart_proses.sql
```

### 6. Dizin İzinlerini Ayarlayın
```bash
chmod -R 755 uploads/
chmod -R 755 assets/
```

## 🏗️ Proje Yapısı

```
panel/
├── application/
│   ├── modules/           # HMVC modülleri
│   │   ├── anasayfa/     # Ana sayfa ve dashboard
│   │   ├── girdikontrol/ # Girdi kontrol modülü
│   │   ├── proseskontrol/# Proses kontrol modülü
│   │   ├── finalkontrol/ # Final kontrol modülü
│   │   ├── malzemeler/   # Malzeme yönetimi
│   │   ├── tedarikciler/ # Tedarikçi yönetimi
│   │   ├── urunler/      # Ürün yönetimi
│   │   ├── users/        # Kullanıcı yönetimi
│   │   └── ...
│   ├── config/           # Konfigürasyon dosyaları
│   ├── controllers/      # Ana controller'lar
│   ├── models/           # Veri modelleri
│   ├── views/            # Görünüm dosyaları
│   └── libraries/        # Özel kütüphaneler
├── assets/               # CSS, JS, resim dosyaları
├── uploads/              # Yüklenen dosyalar
├── system/               # CodeIgniter sistem dosyaları
└── vendor/               # Composer paketleri
```

## 🔐 Kullanıcı Yönetimi

Sistem, rol tabanlı yetki sistemi kullanır:
- **Admin**: Tüm modüllere erişim
- **Kalite Kontrol**: Kontrol modüllerine erişim
- **Planlama**: Planlama modüllerine erişim
- **Operatör**: Sınırlı erişim

## 📊 Ana Modüller

### Girdi Kontrol
- Gelen malzemelerin kalite kontrol kayıtları
- Tedarikçi bazlı değerlendirme
- Red/kabul durumu takibi

### Proses Kontrol
- Üretim sürecindeki kontrol noktaları
- Süreç parametreleri izleme
- Prosese özel kontrol formları

### Final Kontrol
- Son ürün kalite kontrolleri
- Sevkiyat öncesi onay süreçleri
- Müşteri spesifikasyonu uygunluk kontrolü

### Raporlama
- Excel formatında rapor alabilme
- QR kod ile hızlı erişim
- Grafik ve istatistiksel analizler

## 🚀 Kullanım

1. **Giriş**: `/login` sayfasından sisteme giriş yapın
2. **Dashboard**: Ana sayfa üzerinden modüllere erişim
3. **Kontrol Kayıtları**: İlgili modüllerden kontrol kayıtları oluşturun
4. **Raporlama**: Excel export özelliği ile raporlar alın

## 🔧 Konfigürasyon

### E-posta Ayarları
`application/modules/emailsettings/` modülü üzerinden SMTP ayarları yapılabilir.

### QR Kod Ayarları
QR kod üretimi için `application/libraries/Ciqrcode.php` kütüphanesi kullanılmaktadır.

## 📝 Geliştirme Notları

- Sistem HMVC (Hierarchical Model-View-Controller) mimarisi kullanır
- Tüm modüller bağımsız olarak çalışabilir
- Veritabanı işlemleri için CodeIgniter Active Record kullanılır
- Bootstrap 4 tabanlı responsive tasarım

## 🛡️ Güvenlik

- SQL Injection koruması
- XSS (Cross-site scripting) koruması
- CSRF (Cross-site request forgery) koruması
- Oturum güvenliği

## 📞 Destek

Sistem ile ilgili sorularınız için:
- Dokümantasyonu inceleyin
- Kod yorumlarını kontrol edin
- Geliştirici ekibi ile iletişime geçin

---

**Not**: Bu sistem aktif geliştirme aşamasındadır. Güncellemeler için düzenli olarak kontrol edin.
