<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Ürünler Listesi
            <?php   if(isAllowedWriteModule()){ ?>
                <a href="<?php echo base_url("urunler/new_form"); ?>" class="btn btn-outline btn-primary btn-xs pull-right"> <i class="fa fa-plus"></i> Yeni Ekle</a>
            <?php } ?>
        </h4>
    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget">
            <div class="widget-body">
                <form action="<?php echo base_url("urunler/index"); ?>" method="get">
                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="search_title">Ürün Adı</label>
                            <input type="text" name="search_title" class="form-control" placeholder="Ürün adı..." value="<?php echo isset($search_title) ? $search_title : ''; ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="search_desc">Açıklama</label>
                            <input type="text" name="search_desc" class="form-control" placeholder="Açıklama..." value="<?php echo isset($search_desc) ? $search_desc : ''; ?>">
                        </div>
                        <div class="form-group col-md-4 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary mr-2">Ara</button>
                            <a href="<?php echo base_url("urunler"); ?>" class="btn btn-outline-secondary">Temizle</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="widget p-lg">

            <?php if(empty($items)) { ?>

                <div class="alert alert-info text-center">
                    <p>Burada herhangi bir veri bulunmamaktadır. Eklemek için lütfen <a href="<?php echo base_url("urunler/new_form"); ?>">tıklayınız</a></p>
                </div>

            <?php } else { ?>

                <table class="table table-hover table-striped table-bordered content-container">
                    <thead>
                        <th class="order"><i class="fa fa-reorder"></i></th>
                        <th class="w50">#id</th>
                        <th>Adı</th>
                        <th>Kodu</th>
                        <th>İşlem</th>
                    </thead>
                    <tbody class="sortable" data-url="<?php echo base_url("urunler/rankSetter"); ?>">

                        <?php foreach($items as $item) { ?>

                            <tr id="ord-<?php echo $item->id; ?>">
                                <td class="order"><i class="fa fa-reorder"></i></td>
                                <td class="w50 text-center">#<?php echo $item->id; ?></td>
                                <td><?php echo $item->adi; ?></td>
                                <td><?php echo $item->kodu; ?></td>
                                <td class="text-center w200">
                                    <?php   if(isAllowedDeleteModule()){ ?>
                                        <button
                                            data-url="<?php echo base_url("urunler/delete/$item->id"); ?>"
                                            class="btn btn-sm btn-danger btn-outline remove-btn">
                                            <i class="fa fa-trash"></i> Sil
                                        </button>
                                    <?php } ?> 
                                    <?php   if(isAllowedUpdateModule()){ ?>
                                        <a href="<?php echo base_url("urunler/update_form/$item->id"); ?>" class="btn btn-sm btn-info btn-outline"><i class="fa fa-pencil-square-o"></i> Düzenle</a>
                                    <?php } ?>                                   
                                 </td>
                            </tr>

                        <?php } ?>

                    </tbody>

                </table>

            <?php } ?>

            <div class="widget-body">
                <nav aria-label="Page navigation">
                    <?php echo isset($links) ? $links : ""; ?>
                </nav>
            </div>

        </div><!-- .widget -->
    </div><!-- END column -->
</div>