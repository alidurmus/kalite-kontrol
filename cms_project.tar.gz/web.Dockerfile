FROM php:7.4-apache

# Apache için gerekli ortam değişkenlerini tanımla
ENV APACHE_RUN_USER www-data
ENV APACHE_RUN_GROUP www-data
ENV APACHE_LOG_DIR /var/log/apache2
ENV APACHE_RUN_DIR /var/run/apache2
ENV APACHE_PID_FILE /var/run/apache2/apache2.pid

# Gerekli PHP eklentilerini ve kütüphaneleri yükle
RUN apt-get update && apt-get install -y \
    libjpeg-dev \
    libpng-dev \
    libzip-dev \
    zip \
    && docker-php-ext-configure gd --with-jpeg \
    && docker-php-ext-install -j$(nproc) gd mysqli pdo pdo_mysql zip

# Apache mod_rewrite'ı etkinleştir
RUN a2enmod rewrite

# Uygulama kodunu kopyala
COPY . /var/www/html

# İzinleri ayarla (logs ve cache dizinleri için)
RUN mkdir -p /var/www/html/application/cache/sessions
RUN chown -R www-data:www-data /var/www/html/application/logs
RUN chown -R www-data:www-data /var/www/html/application/cache
RUN chmod -R 755 /var/www/html/application/logs
RUN chmod -R 777 /var/www/html/application/cache

WORKDIR /var/www/html

EXPOSE 80 