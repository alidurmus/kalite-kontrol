# Proje Gereksinim Dokümanı (PRD) - CMS ve Kalite Kontrol Paneli

## 1. Giriş

### 1.1. Projenin Amacı

Bu proje, bir imalat şirketinin iş süreçlerini yönetmek, kalite kontrol aşamalarını takip etmek ve genel CMS (İçerik Yönetim Sistemi) ihtiyaçlarını karşılamak üzere geliştirilmiş web tabanlı bir yönetim panelidir. Panel, malzeme ve tedarikçi yönetiminden, üretimdeki kalite kontrol süreçlerine (girdi, proses, final) ve son ürün yönetimine kadar geniş bir yelpazede fonksiyonellik sunar.

### 1.2. Kapsam

Proje, CodeIgniter (HMVC) mimarisi üzerine kurulu modüler bir yapıya sahiptir. Temel olarak iki ana kategoriye ayrılır:
*   **Üretim ve Kalite Yönetimi Modülleri:** Şirketin temel üretim ve kalite süreçlerini dijitalleştiren modüller.
*   **Standart CMS Modülleri:** Web sitesinin içeriğini (haberler, galeriler, portfolyo vb.) yönetmek için kullanılan standart modüller.

---

## 2. Kullanıcı Yönetimi

Sistem, rol tabanlı bir kullanıcı yetkilendirme sistemine sahiptir.

*   **`users` / `kullanicilar`:** Sisteme giriş yapacak kullanıcıların yönetildiği modül (CRUD).
*   **`user_roles`:** Kullanıcı rollerinin (Admin, Operatör vb.) tanımlandığı ve yetkilerinin belirlendiği bölüm.
*   **`signin`:** Kullanıcı giriş işlemlerinin yapıldığı arayüz.

---

## 3. Üretim ve Kalite Yönetimi Modülleri

Bu modüller, projenin ana omurgasını oluşturur ve şirketin operasyonel süreçlerini yönetir.

### 3.1. Kaynak Yönetimi
*   **`tedarikciler`:** Malzeme temin edilen tedarikçi firmaların yönetildiği modül.
    *   **Özellikler:** Listeleme, ekleme, düzenleme, silme, sayfalama, isme ve sorumluya göre arama/filtreleme.
*   **`malzemeler`:** Üretimde kullanılan malzemelerin/hammaddelerin yönetildiği modül.
    *   **Özellikler:** Listeleme, ekleme, düzenleme, silme, sayfalama, malzeme adı ve koduna göre arama/filtreleme.
*   **`urunler` / `products`:** Şirketin ürettiği nihai ürünlerin yönetildiği modül.
    *   **Özellikler:** Listeleme, ekleme, düzenleme, silme, sayfalama, ürün adı ve açıklamasına göre arama/filtreleme.
*   **`musteriler`:** Ürünlerin satıldığı müşteri firmaların yönetildiği modül.
    *   **Özellikler:** Listeleme, ekleme, düzenleme, silme, sayfalama, isme ve sorumluya göre arama/filtreleme.

### 3.2. Üretim Planlama ve Takip
*   **`isemri`:** Üretim için açılan iş emirlerinin takip edildiği modül.
    *   **Özellikler:** Listeleme, ekleme, düzenleme, silme, sayfalama, iş emri no, stok kodu ve parti no'ya göre arama/filtreleme.
*   **`planlama`:** Üretim planlama işlemlerinin yapıldığı modül.

### 3.3. Kalite Kontrol Süreçleri
*   **`girdikontrol`:** Tedarikçiden gelen malzemenin kalite kontrolünün yapıldığı modül.
    *   **Özellikler:** Listeleme, ekleme, düzenleme, silme, sayfalama, tedarikçi, malzeme ve parti no'ya göre arama/filtreleme.
*   **`proseskontrol`:** Üretim aşamasındaki ara kontrollerin kaydedildiği modül.
    *   **Özellikler:** Listeleme, ekleme, düzenleme, silme, sayfalama, ürün adı, lot ve parti no'ya göre arama/filtreleme.
*   **`finalkontrol`:** Üretimi tamamlanmış nihai ürünün son kontrollerinin yapıldığı modül.
    *   **Özellikler:** Listeleme, ekleme, düzenleme, silme, sayfalama, ürün adı, kutu no ve lot'a göre arama/filtreleme.
*   **`kontrol_no`:** Tüm kontrol süreçleri için benzersiz kontrol numaraları üreten ve yöneten sistem.

---

## 4. Yardımcı ve Standart CMS Modülleri

*   **`dashboard`:** Kullanıcıyı giriş sonrası karşılayan, genel bir bakış sunan ana sayfa.
    *   **Veri Azaltma Fonksiyonu:** `dashboard/reduce_data` adresi üzerinden çalışan, veritabanı tablolarındaki kayıtları periyodik olarak (en son 100 kaydı tutacak şekilde) temizleyen bir bakım aracı içerir.
*   **`excel`:** Belirtilen modüllerdeki verileri Excel formatında dışa aktarma yeteneği.
*   **`etiket` / `etiketler`:** Ürünler veya partiler için barkod/QR kod etiketleri oluşturma modülü.
*   **`settings` / `emailsettings`:** Genel panel ayarları ve e-posta yapılandırmaları.
*   **Diğer CMS Modülleri:** `news`, `galleries`, `slides`, `portfolio`, `services`, `brands`, `courses` gibi web sitesinin ön yüzündeki dinamik alanları yönetmek için kullanılan standart içerik yönetimi modülleri.

---

## 5. Teknik Altyapı

*   **Backend Framework:** CodeIgniter (v2 veya v3 tahmini)
*   **Mimari Desen:** HMVC (Hierarchical Model-View-Controller) - `application/modules` ve `MX` kütüphanesi ile sağlanır.
*   **Frontend Teknolojileri:** HTML, CSS, JavaScript, jQuery, Bootstrap.
*   **Veritabanı:** MySQL / MariaDB (XAMPP ortamı ile çalışır).
*   **Listeleme Özellikleri:** Tüm ana modüllerde CodeIgniter Pagination kütüphanesi ile dinamik sayfalama ve GET parametreleri ile çalışan çoklu alan filtreleme/arama özellikleri bulunmaktadır. 